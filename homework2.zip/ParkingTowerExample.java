package homework2;

import java.util.Random;

public class ParkingTowerExample {

	public static void main(String[] args) {
		ParkingTower parkingTower = new ParkingTower();

		Car carByGong = new Sedan("123가1234", "공철수");
		Car carByPark = new Wagon("123가5555", "박영희");
		Car carByHong = new Suv("124다5511", "홍길동");
		Car carByLee = new Sedan("124나1234", "이성계");
		Car carByKim = new Sedan("124다5511", "김미영");
		Car carByJang = new Wagon("124다5511", "장길산");

		putIntoParking(parkingTower, carByGong);
		putIntoParking(parkingTower, carByPark);
		putIntoParking(parkingTower, carByHong);
		putIntoParking(parkingTower, carByLee);
		putIntoParking(parkingTower, carByKim);
		putIntoParking(parkingTower, carByJang);

		Car car = parkingTower.putOff();
		System.out.println(car.getOwner() + "님이 주차장을 나왔습니다.");
		
		putIntoParking(parkingTower, carByJang);
	
	}

	private static void putIntoParking(ParkingTower parkingTower, Car car) {
		if (parkingTower.isEnablePark(car)) {
			parkingTower.putInto(car);
			car.run();
		} else {
			System.out.println(car.getOwner() + "님 주차할 수 없습니다.");
		};
	}
}
